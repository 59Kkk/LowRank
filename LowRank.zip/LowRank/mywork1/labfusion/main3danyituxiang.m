clear
clc

disp('----------vector_main------------');
% load matrices
load('./models/L_8_detail_mix_2000_s1000.mat');
load('./models/L_16_detail_mix_2000_s1000.mat');

% 0 - without zca, 1 - use zca
isZCA = 0;
is_overlap = 1;

% �����趨
stride_cell = {1,2,4,6,8,10,12,14}; % for 16*16. In our paper is 1.
[n_s, m_s] = size(stride_cell);
norm_cell = {'l1', 'nu'}; % l1 - l1 norm; nu - nuclear norm. In our paper is nuclear norm.
[n_norm, m_norm] = size(norm_cell);
L_cell = {'8', '16'}; % projecting matrix. In our paper is 16.
[n_L, m_L] = size(L_cell);
level_cell = {1,2,3,4,5,6,7,8}; % decomposition level. In our paper is 1 to 4.
[n_le, m_le] = size(level_cell);

for s=1:1
stride = stride_cell{s}; 
% l1, nu
for kk=2:m_norm
    norm = norm_cell{kk};
    %%%%% 8, 16 %%%%%%%%%%%%%%%
    for k=2:m_L
        eval(['L = L_', L_cell{k}, ';'])
        unit = str2double(L_cell{k});
        % decomposition level 1 - 8
        for jj=1:4
            de_level = level_cell{jj};
            str_t = ['L_',L_cell{k},'; level: ',num2str(de_level),'; norm: ',norm, '; stride: ', num2str(stride)];
            disp(str_t);
            t = 0;
            %for j=1:8
                index = 2;%Ҫ�ĵ�
                %path1 = ['./picture/gamma correction',num2str(index),'.jpg'];
                %path2 = ['./picture/sharp',num2str(index),'.jpg'];
                path1 = ['./picture/gamma correction2','.jpg'];%Ҫ�ĵ�
                path2 = ['./picture/sharp2','.jpg'];
                if is_overlap == 1
                    path_temp = './fused/';
                    if exist(path_temp,'dir')==0
                        mkdir(path_temp);
                    end
                    fuse_path = [path_temp, 'fused',num2str(index), '_mdlatlrr_level_',num2str(de_level),'_',norm,'_stride_',num2str(stride),'.png'];
                end
                if exist(fuse_path,'file')~=0
                    continue;
                end
                % Fusion
                img1 = imread(path1);
                %
                 img1R=img1(:,:,1);
                 img1G=img1(:,:,2);
                 img1B=img1(:,:,3);
                 %�²���
%                 img1R=img1R(1:2:end,1:2:end);
%                 img1G=img1G(1:2:end,1:2:end);
%                 img1B=img1B(1:2:end,1:2:end);
                %img1=cat(3,img1R,img1G,img1B);%ÿ2λ�ɼ�1λ
       
                img1R = im2double(img1R);
                img1G = im2double(img1G);
                img1B = im2double(img1B);
                
                
                img2 = imread(path2);
                %           
                img2R=img2(:,:,1);
                img2G=img2(:,:,2);
                img2B=img2(:,:,3);
                %�²���
%                 img2R=img2R(1:2:end,1:2:end);
%                 img2G=img2G(1:2:end,1:2:end);
%                 img2B=img2B(1:2:end,1:2:end);
                %img2=cat(3,img2R,img2G,img2B);%ÿ2λ�ɼ�1λ
                
                img2R = im2double(img2R);
                img2G = im2double(img2G);   
                img2B = im2double(img2B);   
                
                  %%
                  %Rͨ��ͼ��   
                  img1 = img1R;
                  img2 = img2R;
                [h,w] = size(img1);
                F = zeros(h,w);
                is_block = 0;
                tic
                if h>512 || w>512
                    % get image block
                    is_block = 1;
                    [img1_1, img1_2, img1_3, img1_4] = getImgBlock(img1);
                    [img2_1, img2_2, img2_3, img2_4] = getImgBlock(img2);
                end
                if is_block == 1
                    F_1 = vector_fusion_method(img1_1, img2_1, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F_2 = vector_fusion_method(img1_2, img2_2, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F_3 = vector_fusion_method(img1_3, img2_3, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F_4 = vector_fusion_method(img1_4, img2_4, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F = reconsFromBlock(F,F_1, F_2,F_3, F_4);
                    FR = F;
                elseif is_block == 0
                    F = vector_fusion_method(img1, img2, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    FR = F;
                end
                %%
                %Gͨ��ͼ��
                img1 = img1G;
                img2 = img2G;
                [h,w] = size(img1);
                F = zeros(h,w);
                is_block = 0;
                tic
                if h>512 || w>512
                    % get image block
                    is_block = 1;
                    [img1_1, img1_2, img1_3, img1_4] = getImgBlock(img1);
                    [img2_1, img2_2, img2_3, img2_4] = getImgBlock(img2);
                end
                if is_block == 1
                    F_1 = vector_fusion_method(img1_1, img2_1, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F_2 = vector_fusion_method(img1_2, img2_2, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F_3 = vector_fusion_method(img1_3, img2_3, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F_4 = vector_fusion_method(img1_4, img2_4, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F = reconsFromBlock(F,F_1, F_2,F_3, F_4);
                    FG = F;
                elseif is_block == 0
                    F = vector_fusion_method(img1, img2, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    FG = F;
                end
                %%
                %Bͨ��ͼ��
                img1 = img1B;
                img2 = img2B;
                [h,w] = size(img1);
                F = zeros(h,w);
                is_block = 0;
                tic
                if h>512 || w>512
                    % get image block
                    is_block = 1;
                    [img1_1, img1_2, img1_3, img1_4] = getImgBlock(img1);
                    [img2_1, img2_2, img2_3, img2_4] = getImgBlock(img2);
                end
                if is_block == 1
                    F_1 = vector_fusion_method(img1_1, img2_1, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F_2 = vector_fusion_method(img1_2, img2_2, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F_3 = vector_fusion_method(img1_3, img2_3, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F_4 = vector_fusion_method(img1_4, img2_4, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    F = reconsFromBlock(F,F_1, F_2,F_3, F_4);
                    FB = F;
                elseif is_block == 0
                    F = vector_fusion_method(img1, img2, L, unit, isZCA, de_level, norm, is_overlap, stride);
                    FB = F;
                end
                %%
                %F = cat(3,FR,FG,FB);
                F(:,:,1)=FR;
                F(:,:,2)=FG;
                F(:,:,3)=FB;
                str_o = [str_t, '; index: ', num2str(index), '; time: ', num2str(toc)];
                disp(str_o);
                imwrite(F,fuse_path,'png');
                %imwrite(F,'E:\���\fuse_path.jpg');
%                 for j=1:10
%                  strl= ['E:\���\fuse_path\fusion']%ͼ����Ҫ����ĵ�ַ�����ļ�����ǰ�벿��
%                  imwrite(F,[strl num2str(j) '.jpg' ])
%                 end
        %end
        end
    end
end
end
% end